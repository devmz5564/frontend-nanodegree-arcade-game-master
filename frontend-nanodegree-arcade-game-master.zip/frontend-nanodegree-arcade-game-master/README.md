# FEND-Arcade-Game
===============================
This is my Arcade Game 
DESKTOP ONLY!
Wish you'll find it entertaining!

### Installation instructions
*   Download the repository: click download ZIP on the right of the screen and extract the zip file to your computer or clone the repository using Git.
*   Navigate to where you unzipped the file or cloned the repository.
*   Double-click index.html to open the game in your browser.
* Play!.

### How to play:
* Use arrow keys to move up, down, left, right.
* Try to reach water to win the game.
* 